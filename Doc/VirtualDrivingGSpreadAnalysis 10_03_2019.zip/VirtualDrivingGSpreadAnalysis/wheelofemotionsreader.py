'''
Created on 01.02.2019

@author: Lukas
'''

import math
import gspread
from oauth2client.service_account import ServiceAccountCredentials

alpha = (9+0*18)*(math.pi/180)
a = 0.33
c = math.sqrt((2 * math.pow(a,2)) - (2 * math.pow(a,2) * math.cos(alpha)))
hc = a * math.sin(alpha)
x = math.sqrt(math.pow(a,2)-math.pow(hc, 2))

class Coord:
    def __init__(self, chx, chy, cmx, cmy, clx, cly):
        self.hx = chx
        self.hy = chy
        self.mx = cmx
        self.my = cmy
        self.lx = clx
        self.ly = cly

def fill_emotions():
    cx1 = 0.15643446504023076
    cx2 = 0.4539904997395469
    cx3 = 0.7071067811865475
    cx4 = 0.8910065241883679
    cx5 = 0.9876883405951378
    
    cy1 = 0.10324674692655238
    cy2 = 0.2996337298281009
    cy3 = 0.46669047558312143
    cy4 = 0.5880643059643228
    cy5 = 0.651874304792791
    
    cz1 = 0.05162337346327619
    cz2 = 0.14981686491405044
    cz3 = 0.23334523779156072
    cz4 = 0.2940321529821614
    cz5 = 0.3259371523963955

    emotinion_dict = {}
    emotinion_dict['Interest'] = Coord(cx1,cx5,cy1,cy5,cz1,cz5)
    emotinion_dict['Amusement'] = Coord(cx2,cx4,cy2,cy4,cz2,cz4)
    emotinion_dict['Pride'] = Coord(cx3,cx3,cy3,cy3,cz3,cz3)
    emotinion_dict['Joy'] = Coord(cx4,cx2,cy4,cy2,cz4,cz2)
    emotinion_dict['Pleasure'] = Coord(cx5,cx1,cy5,cy1,cz5,cz1)
    
    emotinion_dict['Contentment'] = Coord(cx5,-cx1,cy5,-cy1,cz5,-cz1)
    emotinion_dict['Love'] = Coord(cx4,-cx2,cy4,-cy2,cz4,-cz2)
    emotinion_dict['Admiration'] = Coord(cx3,-cx3,cy3,-cy3,cz3,-cz3)
    emotinion_dict['Relief'] = Coord(cx2,-cx4,cy2,-cy4,cz2,-cz4)
    emotinion_dict['Compassion'] = Coord(cx1,-cx5,cy1,-cy5,cz1,-cz5)
    
    emotinion_dict['Sadness'] = Coord(-cx1,-cx5,-cy1,-cy5,-cz1,-cz5)
    emotinion_dict['Guilt'] = Coord(-cx2,-cx4,-cy2,-cy4,-cz2,-cz4)
    emotinion_dict['Regret'] = Coord(-cx3,-cx3,-cy3,-cy3,-cz3,-cz3)
    emotinion_dict['Shame'] = Coord(-cx4,-cx2,-cy4,-cy2,-cz4,-cz2)
    emotinion_dict['Disappointment'] = Coord(-cx5,-cx1,-cy5,-cy1,-cz5,-cz1)
    
    emotinion_dict['Fear'] = Coord(-cx5,cx1,-cy5,cy1,-cz5,cz1)
    emotinion_dict['Disgust'] = Coord(-cx4,cx2,-cy4,cy2,-cz4,cz2)
    emotinion_dict['Contempt'] = Coord(-cx3,cx3,-cy3,cy3,-cz3,cz3)
    emotinion_dict['Hate'] = Coord(-cx2,cx4,-cy2,cy4,-cz2,cz4)
    emotinion_dict['Anger'] = Coord(-cx1,cx5,-cy1,cy5,-cz1,cz5)
    return emotinion_dict

emotionsdict = fill_emotions()

class Emotion:
    def __init__(self, idpart, roundpart, highpart, mediumpart, lowpart):
        self.id = idpart
        self.round = roundpart
        self.high = highpart
        self.medium = mediumpart
        self.low = lowpart
       
    def toString(self):
        return self.id + " " + str(self.round) + " " + str(self.high)
    
    def getHighCoord(self):
        return emotionsdict[self.high].hx, emotionsdict[self.high].hy
    
    def getMediumCoord(self):
        return emotionsdict[self.medium].mx, emotionsdict[self.medium].my
    
    def getLowCoord(self):
        return emotionsdict[self.low].lx, emotionsdict[self.low].ly
    
    def getMiddleCoord(self):
        return (emotionsdict[self.high].hx + emotionsdict[self.medium].mx + emotionsdict[self.low].lx) / 3, (emotionsdict[self.high].hy + emotionsdict[self.medium].my + emotionsdict[self.low].ly) / 3
    
class Emotionreader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('vdquestionary (Data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        emotion_list = {}
        for r in self.recs:
            id_string = r['ID']
            round_string = r['Round']
            high_string = r['High']
            medium_string = r['Medium']
            low_string = r['Low']
            em = Emotion(id_string, round_string, high_string, medium_string, low_string)
            if em.id not in emotion_list.keys():
                emotion_list[em.id] = []
            emotion_list[em.id].append(em)
        return emotion_list
    
    