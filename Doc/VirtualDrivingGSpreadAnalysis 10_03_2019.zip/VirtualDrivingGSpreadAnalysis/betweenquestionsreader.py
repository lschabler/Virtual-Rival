'''
Created on 06.02.2019

@author: Lukas
'''

import gspread
from oauth2client.service_account import ServiceAccountCredentials

class BetweenQuestion:
    def __init__(self, idpart, roundpart, funpart, skillpart):
        self.id = idpart
        self.round = roundpart
        self.fun = funpart
        self.skill = skillpart
        
    def toString(self):
        return str(self.id) + " " + str(self.round)
    
    def getRound(self):
        return self.round
    
    def getFun(self):
        return self.fun
    
    def getSkill(self):
        return self.skill
    

class Betweenquestionreader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('betweenquestionary (data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        question_list = {}
        for r in self.recs:
            rid = r['ID']
            rround = r['Round']
            rfun = r['Fun']
            rskill = r['Skill']

            if rid not in question_list.keys():
                question_list[rid] = []
            question_list[rid].append(BetweenQuestion(rid, rround, rfun, rskill))
            
        return question_list