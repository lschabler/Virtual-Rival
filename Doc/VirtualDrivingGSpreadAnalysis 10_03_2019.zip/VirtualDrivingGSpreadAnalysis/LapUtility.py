'''
Created on 01.02.2019

@author: Lukas
'''
import csv
import math

def getFastestRound(rounds):
    fastest = float("inf")
    
    for r in rounds:
        if(r.type == 'TRACK1' and fastest > r.time[-1]):
            fastest = r.time[-1]
    
    return fastest

def getFastestSpeed(rounds):
    fastest = float("-inf")
    
    for r in rounds:
        if(r.type == 'TRACK1' and fastest < max(r.speed)):
            fastest = max(r.speed)
    
    return fastest

def getAvgErrors(rounds):
    nr_errors = 0
    
    for r in rounds:     
        last_contact_point = 0
        for i in range(0,len(r.contactpoints_time)):
            if(abs(r.contactpoints_time[i] - last_contact_point) > 0.5):
                last_contact_point = r.contactpoints_time[i]
                nr_errors+=1       
            
    return nr_errors/6

def getAvgEmotions(emotions):
    total_motivation = 0
    total_positiv = 0
    
    for r in emotions: 
        if r.round < 3:
            continue
        em = r.getMiddleCoord()  
        total_positiv += em[0]  
        total_motivation += em[1]
            
    return total_positiv / 3, total_motivation / 3

def getImprovement(rounds):
    improvment_time = float("-inf")
    for i in range(3,len(rounds)):
        improvment_dif = rounds[2].time[-1] - rounds[i].time[-1] 
        if improvment_dif > improvment_time:
            improvment_time = improvment_dif
    
    return improvment_time

def filterIDs(ids, laps):

    filtered_ids = []
    
    with open('ids.csv', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
        for row in spamreader:
            ids.append(row[1]) 

    for l in laps:
        if(len(laps[l]) < 6):
            continue
        if l not in ids:
            continue
        
        fps_to_low = False
        
        for i in laps[l]:
            if i.getAvgFPS() < 20:
                fps_to_low = True
                
        if fps_to_low == False:
            filtered_ids.append(l)        
    
    return filtered_ids

def filterType(ids, initialquestions):
    time_ids = []
    ghost_ids = []
    
    for i in ids:
        if initialquestions[i].isTime():
            time_ids.append(i)
        else:
            ghost_ids.append(i)

    return [time_ids, ghost_ids]

def getWinOrLoss(ids, laps):
    for i in ids:
        for lap in laps[i]:
            if lap.oppid == 'No Opponent':
                continue
            opp_round = laps[lap.oppid][lap.oppround-1].getLapTime()
            cur_round = lap.getLapTime()
            dif = cur_round - opp_round
            if cur_round < opp_round:
                lap.setWinOrLoss(1, dif)
            else:
                lap.setWinOrLoss(0, dif)
                
def getFun(betweenquestions):
    fun = 0
    for i in betweenquestions:
        fun += i.getFun()
    return fun

def getSkill(betweenquestions):
    skill = 0
    for i in betweenquestions:
        skill += i.getSkill()
    return skill

def getErrorTimeDifToGhost(laps, lap):
    timedif = []
    dist = []
    
    opp = laps[lap.oppid][lap.oppround-1]
    
    last_contact_point = 0
    for i in range(0,len(lap.contactpoints_time)):
            
        if(abs(lap.contactpoints_time[i] - last_contact_point) > 0.5):
            last_contact_point = lap.contactpoints_time[i]
            last_contact_point_pos = lap.contactpoints_position[i]
            
            pos_dif = float('inf')
            pos_index = -1
            time_dif = float('inf')
            time_index = -1
            for j in range(0,len(opp.time)):
                temp_dif = abs(last_contact_point - opp.time[j])
                tmp_pos_dif = math.sqrt(math.pow(last_contact_point_pos.x - opp.pos_x[j], 2) + math.pow(last_contact_point_pos.y - opp.pos_y[j], 2) + math.pow(last_contact_point_pos.z - opp.pos_z[j], 2))
                
                if(temp_dif < time_dif):
                    time_dif = temp_dif
                    time_index = j
                    
                if(tmp_pos_dif < pos_dif):
                    pos_dif = tmp_pos_dif
                    pos_index = j
            
            
            #print(lap.contactpoints_position[i].toString())
            #print(str(opp.pos_x[time_index]) + ' ' + str(opp.pos_y[time_index]) + ' ' + str(opp.pos_z[time_index]))
            
            #print(pos_dif)
            timedif.append(opp.time[pos_index] - last_contact_point)
            tmp = math.sqrt(math.pow(last_contact_point_pos.x - opp.pos_x[time_index], 2) + math.pow(last_contact_point_pos.y - opp.pos_y[time_index], 2) + math.pow(last_contact_point_pos.z - opp.pos_z[time_index], 2))
            dist.append(tmp)
            
    return timedif, dist