'''
Created on 02.02.2019

@author: Lukas
'''

from scipy import stats
import LapUtility
from dask.array.fft import scipy
    

def calcPearSpear(a, b, title = ''):
    pear = stats.pearsonr(a, b)
    spear = stats.spearmanr(a, b)
    retstr =  title + ', ' + str(pear[0]) + ', ' + str(pear[1]) + ', ' + str(spear[0]) + ', ' + str(spear[1])
    return [pear[0], pear[1], spear[0], spear[1], retstr]

def statSensationRound(laps, sens, ids):
    
    fastest_lap = []
    fastest_speed = []
    avg_errors = []
    overall_improvment = []
    
    experience_seeking = []
    disinhibition_seeking = []
    bordom_seeking = []
    thrill_seeking = []
    sensation_seeking = []
    
    for l in ids:
        if(len(laps[l]) < 6):
            continue
        
        fastest_lap.append(LapUtility.getFastestRound(laps[l]))
        fastest_speed.append(LapUtility.getFastestSpeed(laps[l]))
        avg_errors.append(LapUtility.getAvgErrors(laps[l]))
        overall_improvment.append(LapUtility.getImprovement(laps[l]))
        
        sensation = sens[l]
        experience_seeking.append(sensation.getExperienceSeeking())
        disinhibition_seeking.append(sensation.getDisinhibitionSeeking())
        bordom_seeking.append(sensation.getBordomSeeking())
        thrill_seeking.append(sensation.getThrillSeeking())
        sensation_seeking.append(sensation.getSensationSeeking())
    
    pear_exp_fast = stats.pearsonr(fastest_lap, experience_seeking)
    spear_exp_fast = stats.spearmanr(fastest_lap, experience_seeking)
    
    pear_dis_fast = stats.pearsonr(fastest_lap, disinhibition_seeking)
    spear_dis_fast = stats.spearmanr(fastest_lap, disinhibition_seeking)
    
    pear_bor_fast = stats.pearsonr(fastest_lap, bordom_seeking)
    spear_bor_fast = stats.spearmanr(fastest_lap, bordom_seeking)
    
    pear_thrill_fast = stats.pearsonr(fastest_lap, thrill_seeking)
    spear_thrill_fast = stats.spearmanr(fastest_lap, thrill_seeking)
    
    pear_sen_fast = stats.pearsonr(fastest_lap, sensation_seeking)
    spear_sen_fast = stats.spearmanr(fastest_lap, sensation_seeking)
    
    print("Experience seeking - Fastest round: ", pear_exp_fast[0], pear_exp_fast[1], spear_exp_fast[0], spear_exp_fast[1])
    print("Disinhibition seeking - Fastest round: ", pear_dis_fast[0], pear_dis_fast[1], spear_dis_fast[0], spear_dis_fast[1])
    print("Boredom susceptibility seeking - Fastest round: ", pear_bor_fast[0], pear_bor_fast[1], spear_bor_fast[0], spear_bor_fast[1])
    print("Thrill and adventure seeking - Fastest round: ", pear_thrill_fast[0], pear_thrill_fast[1], spear_thrill_fast[0], spear_thrill_fast[1])
    print("Sensation seeking - Fastest round: ", pear_sen_fast[0], pear_sen_fast[1], spear_sen_fast[0], spear_sen_fast[1])
    
    print('')
    pear_exp_speed = stats.pearsonr(fastest_speed, experience_seeking)
    spear_exp_speed = stats.spearmanr(fastest_speed, experience_seeking)
    
    pear_dis_speed = stats.pearsonr(fastest_speed, disinhibition_seeking)
    spear_dis_speed = stats.spearmanr(fastest_speed, disinhibition_seeking)
    
    pear_bor_speed = stats.pearsonr(fastest_speed, bordom_seeking)
    spear_bor_speed = stats.spearmanr(fastest_speed, bordom_seeking)
    
    pear_thrill_speed = stats.pearsonr(fastest_speed, thrill_seeking)
    spear_thrill_speed = stats.spearmanr(fastest_speed, thrill_seeking)
    
    pear_sen_speed = stats.pearsonr(fastest_speed, sensation_seeking)
    spear_sen_speed = stats.spearmanr(fastest_speed, sensation_seeking)
    
    print("Experience seeking - Fastest speed: ", pear_exp_speed[0], pear_exp_speed[1], spear_exp_speed[0], spear_exp_speed[1])
    print("Disinhibition seeking - Fastest speed: ", pear_dis_speed[0], pear_dis_speed[1], spear_dis_speed[0], spear_dis_speed[1])
    print("Boredom susceptibility seeking - Fastest speed: ", pear_bor_speed[0], pear_bor_speed[1], spear_bor_speed[0], spear_bor_speed[1])
    print("Thrill and adventure seeking - Fastest speed: ", pear_thrill_speed[0], pear_thrill_speed[1], spear_thrill_speed[0], spear_thrill_speed[1])
    print("Sensation seeking - Fastest speed: ", pear_sen_speed[0], pear_sen_speed[1], spear_sen_speed[0], spear_sen_speed[1])
    
    print('')
    pear_exp_avg_errors = stats.pearsonr(avg_errors, experience_seeking)
    spear_exp_avg_errors = stats.spearmanr(avg_errors, experience_seeking)
    
    pear_dis_avg_errors = stats.pearsonr(avg_errors, disinhibition_seeking)
    spear_dis_avg_errors = stats.spearmanr(avg_errors, disinhibition_seeking)
    
    pear_bor_avg_errors = stats.pearsonr(avg_errors, bordom_seeking)
    spear_bor_avg_errors = stats.spearmanr(avg_errors, bordom_seeking)
    
    pear_thrill_avg_errors = stats.pearsonr(avg_errors, thrill_seeking)
    spear_thrill_avg_errors = stats.spearmanr(avg_errors, thrill_seeking)
    
    pear_sen_avg_errors = stats.pearsonr(avg_errors, sensation_seeking)
    spear_sen_avg_errors = stats.spearmanr(avg_errors, sensation_seeking)
    
    print("Experience seeking - Avg errors: ", pear_exp_avg_errors[0], pear_exp_avg_errors[1], spear_exp_avg_errors[0], spear_exp_avg_errors[1])
    print("Disinhibition seeking - Avg errors: ", pear_dis_avg_errors[0], pear_dis_avg_errors[1], spear_dis_avg_errors[0], spear_dis_avg_errors[1])
    print("Boredom susceptibility seeking - Avg errors: ", pear_bor_avg_errors[0], pear_bor_avg_errors[1], spear_bor_avg_errors[0], spear_bor_avg_errors[1])
    print("Thrill and adventure seeking - Avg errors: ", pear_thrill_avg_errors[0], pear_thrill_avg_errors[1], spear_thrill_avg_errors[0], spear_thrill_avg_errors[1])
    print("Sensation seeking - Avg errors: ", pear_sen_avg_errors[0], pear_sen_avg_errors[1], spear_sen_avg_errors[0], spear_sen_avg_errors[1])
    
    print()
    
    print(calcPearSpear(overall_improvment, experience_seeking, 'Experience seeking - Overall improvment: "')[4]) 
    print(calcPearSpear(overall_improvment, disinhibition_seeking, 'Disinhibition seeking - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, bordom_seeking, 'Boredom susceptibility - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, thrill_seeking, 'Thrill and adventure seeking - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, sensation_seeking, 'Sensation seeking - Overall improvment: "')[4])   

def statBigFiveRound(laps, bigfives, ids):
    
    fastest_lap = []
    fastest_speed = []
    avg_errors = []
    overall_improvment = []
    
    agreeableness = []
    conscientiousness = []
    extraversion = []
    neuroticism = []
    openess = []
    
    for l in laps:
        if(len(laps[l]) < 6):
            continue
    
        if not (l in ids):
            continue
        
        fastest_lap.append(LapUtility.getFastestRound(laps[l]))
        fastest_speed.append(LapUtility.getFastestSpeed(laps[l]))
        avg_errors.append(LapUtility.getAvgErrors(laps[l])) 
        overall_improvment.append(LapUtility.getImprovement(laps[l]))
        
        bigfive = bigfives[l]
        agreeableness.append(bigfive.getAgreeableness())
        conscientiousness.append(bigfive.getConscientiousness())
        extraversion.append(bigfive.getExtraversion())
        neuroticism.append(bigfive.getNeuroticism())
        openess.append(bigfive.getOpenness())
     
    print(calcPearSpear(fastest_lap, agreeableness, 'Agreeableness - Fastest round: "')[4]) 
    print(calcPearSpear(fastest_lap, conscientiousness, 'Conscientiousness - Fastest round: "')[4])   
    print(calcPearSpear(fastest_lap, extraversion, 'Extraversion - Fastest round: "')[4])   
    print(calcPearSpear(fastest_lap, neuroticism, 'Neuroticism - Fastest round: "')[4])   
    print(calcPearSpear(fastest_lap, openess, 'Openess - Fastest round: "')[4])        
    
    print()
    
    print(calcPearSpear(fastest_speed, agreeableness, 'Agreeableness - Fastest speed: "')[4]) 
    print(calcPearSpear(fastest_speed, conscientiousness, 'Conscientiousness - Fastest speed: "')[4])   
    print(calcPearSpear(fastest_speed, extraversion, 'Extraversion - Fastest speed: "')[4])   
    print(calcPearSpear(fastest_speed, neuroticism, 'Neuroticism - Fastest speed: "')[4])   
    print(calcPearSpear(fastest_speed, openess, 'Openess - Fastest speed: "')[4])     
    
    print()
    
    print(calcPearSpear(avg_errors, agreeableness, 'Agreeableness - Avg errors: "')[4]) 
    print(calcPearSpear(avg_errors, conscientiousness, 'Conscientiousness - Avg errors: "')[4])   
    print(calcPearSpear(avg_errors, extraversion, 'Extraversion - Avg errors: "')[4])   
    print(calcPearSpear(avg_errors, neuroticism, 'Neuroticism - Avg errors: "')[4])   
    print(calcPearSpear(avg_errors, openess, 'Openess - Avg errors: "')[4]) 
    
    print()
    
    print(calcPearSpear(overall_improvment, agreeableness, 'Agreeableness - Overall improvment: "')[4]) 
    print(calcPearSpear(overall_improvment, conscientiousness, 'Conscientiousness - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, extraversion, 'Extraversion - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, neuroticism, 'Neuroticism - Overall improvment: "')[4])   
    print(calcPearSpear(overall_improvment, openess, 'Openess - Overall improvment: "')[4])        
    
def statFunSkill(laps, betweenquestions, ids):
    win = []
    dif = []
    dif_abs = []
    skill = []
    fun = []
    
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1:
                continue
            else:
                win.append(res[0])
                dif.append(res[1])
                dif_abs.append(abs(res[1]))
                skill.append(betweenquestions[lap.oppid][lap.oppround-1].getSkill())
                fun.append(betweenquestions[lap.oppid][lap.oppround-1].getFun())

    print(calcPearSpear(win, skill, 'Win - Do better: "')[4]) 
    print(calcPearSpear(win, fun, 'Win - Fun: "')[4])   
    
    print(calcPearSpear(dif, skill, 'Time Dif Opponent - Do better: "')[4]) 
    print(calcPearSpear(dif, fun, 'Time Dif Opponent - Fun: "')[4])   
    
    print(calcPearSpear(dif_abs, skill, 'Abs Time Dif Opponent - Do better: "')[4]) 
    print(calcPearSpear(dif_abs, fun, 'Abs Time Dif Opponent - Fun: "')[4])  

def statFunSkillDrivingPeformance(laps, betweenquestions, ids):
    
    fastest_lap = []
    fastest_speed = []
    avg_errors = []
    overall_improvment = []  
    
    total_fun = []
    total_skill = []
    
    for l in ids:
        if(len(laps[l]) < 6):
            continue 
        
        fastest_lap.append(LapUtility.getFastestRound(laps[l]))
        fastest_speed.append(LapUtility.getFastestSpeed(laps[l]))
        avg_errors.append(LapUtility.getAvgErrors(laps[l]))
        overall_improvment.append(LapUtility.getImprovement(laps[l]))
        
        total_fun.append(LapUtility.getFun(betweenquestions[l]))
        total_skill.append(LapUtility.getSkill(betweenquestions[l]))
        
    print(calcPearSpear(fastest_lap, total_fun, 'Fast Lap - Fun: "')[4]) 
    print(calcPearSpear(fastest_lap, total_skill, 'Fast Lap - Skill: "')[4]) 
    
    print(calcPearSpear(fastest_speed, total_fun, 'Fast Speed - Fun: "')[4]) 
    print(calcPearSpear(fastest_speed, total_skill, 'Fast Speed - Skill: "')[4]) 
    
    print(calcPearSpear(avg_errors, total_fun, 'Avg Errors - Fun: "')[4]) 
    print(calcPearSpear(avg_errors, total_skill, 'Avg Errors - Skill: "')[4]) 
    
    print(calcPearSpear(overall_improvment, total_fun, 'Improvment - Fun: "')[4]) 
    print(calcPearSpear(overall_improvment, total_skill, 'Improvment - Skill: "')[4]) 
    
def statEmotionsDrivingPeformance(laps, emotions, ids):
    
    fastest_lap = []
    fastest_speed = []
    avg_errors = []
    overall_improvment = []  
    
    medium_emotion_positiv = []
    medium_emotion_motivation = []
    
    for l in ids:
        if(len(laps[l]) < 6):
            continue 
        
        fastest_lap.append(LapUtility.getFastestRound(laps[l]))
        fastest_speed.append(LapUtility.getFastestSpeed(laps[l]))
        avg_errors.append(LapUtility.getAvgErrors(laps[l]))
        overall_improvment.append(LapUtility.getImprovement(laps[l]))
        
        avg_em = LapUtility.getAvgEmotions(emotions[l])
        medium_emotion_positiv.append(avg_em[0])
        medium_emotion_motivation.append(avg_em[1])
        
    print(calcPearSpear(fastest_lap, medium_emotion_positiv, 'Fastest Lap - Positiv: "')[4]) 
    print(calcPearSpear(fastest_lap, medium_emotion_motivation, 'Fastest Lap - Motivation: "')[4]) 
    
    print(calcPearSpear(fastest_speed, medium_emotion_positiv, 'Speed - Positiv: "')[4]) 
    print(calcPearSpear(fastest_speed, medium_emotion_motivation, 'Speed - Motivation: "')[4]) 
    
    print(calcPearSpear(avg_errors, medium_emotion_positiv, 'Avg Errors - Positiv: "')[4]) 
    print(calcPearSpear(avg_errors, medium_emotion_motivation, 'Avg Errors - Motivation: "')[4]) 
    
    print(calcPearSpear(overall_improvment, medium_emotion_positiv, 'Improvment - Positiv: "')[4]) 
    print(calcPearSpear(overall_improvment, medium_emotion_motivation, 'Improvment - Motivation: "')[4]) 
    
def statFunSkillSensation(betweenquestions, sens, ids):
    
    total_fun = []
    total_skill = []
    
    experience_seeking = []
    disinhibition_seeking = []
    bordom_seeking = []
    thrill_seeking = []
    sensation_seeking = []
    
    for l in ids:
        
        total_fun.append(LapUtility.getFun(betweenquestions[l]))
        total_skill.append(LapUtility.getSkill(betweenquestions[l]))
        
        sensation = sens[l]
        experience_seeking.append(sensation.getExperienceSeeking())
        disinhibition_seeking.append(sensation.getDisinhibitionSeeking())
        bordom_seeking.append(sensation.getBordomSeeking())
        thrill_seeking.append(sensation.getThrillSeeking())
        sensation_seeking.append(sensation.getSensationSeeking())
    
    print(calcPearSpear(experience_seeking, total_fun, 'Experience seeking - Fun: "')[4]) 
    print(calcPearSpear(experience_seeking, total_skill, 'Experience seeking - Skill: "')[4]) 
    
    print(calcPearSpear(disinhibition_seeking, total_fun, 'Disinhibition seeking - Fun: "')[4]) 
    print(calcPearSpear(disinhibition_seeking, total_skill, 'Disinhibition seeking - Skill: "')[4]) 
    
    print(calcPearSpear(bordom_seeking, total_fun, 'Bordom seeking - Fun: "')[4]) 
    print(calcPearSpear(bordom_seeking, total_skill, 'Bordom seeking - Skill: "')[4]) 
    
    print(calcPearSpear(thrill_seeking, total_fun, 'Thrill seeking - Fun: "')[4]) 
    print(calcPearSpear(thrill_seeking, total_skill, 'Thrill seeking - Skill: "')[4]) 
    
    print(calcPearSpear(sensation_seeking, total_fun, 'Sensation seeking - Fun: "')[4]) 
    print(calcPearSpear(sensation_seeking, total_skill, 'Sensation seeking - Skill: "')[4]) 
    
def statEmotionSensation(emotions, sens, ids):
    
    medium_emotion_positiv = []
    medium_emotion_motivation = []
    
    experience_seeking = []
    disinhibition_seeking = []
    bordom_seeking = []
    thrill_seeking = []
    sensation_seeking = []
    
    for l in ids:  
        avg_em = LapUtility.getAvgEmotions(emotions[l])
        medium_emotion_positiv.append(avg_em[0])
        medium_emotion_motivation.append(avg_em[1])
        
        sensation = sens[l]
        experience_seeking.append(sensation.getExperienceSeeking())
        disinhibition_seeking.append(sensation.getDisinhibitionSeeking())
        bordom_seeking.append(sensation.getBordomSeeking())
        thrill_seeking.append(sensation.getThrillSeeking())
        sensation_seeking.append(sensation.getSensationSeeking())
    
    print(calcPearSpear(experience_seeking, medium_emotion_positiv, 'Experience seeking - Positiv: "')[4])  
    print(calcPearSpear(disinhibition_seeking, medium_emotion_positiv, 'Disinhibition seeking - Positiv: "')[4]) 
    print(calcPearSpear(bordom_seeking, medium_emotion_positiv, 'Bordom seeking - Positiv: "')[4]) 
    print(calcPearSpear(thrill_seeking, medium_emotion_positiv, 'Thrill seeking - Positiv: "')[4]) 
    print(calcPearSpear(sensation_seeking, medium_emotion_positiv, 'Sensation seeking - Positiv: "')[4]) 
    
    print(calcPearSpear(experience_seeking, medium_emotion_motivation, 'Experience seeking - Motivation: "')[4])  
    print(calcPearSpear(disinhibition_seeking, medium_emotion_motivation, 'Disinhibition seeking - Motivation: "')[4]) 
    print(calcPearSpear(bordom_seeking, medium_emotion_motivation, 'Bordom seeking - Motivation: "')[4]) 
    print(calcPearSpear(thrill_seeking, medium_emotion_motivation, 'Thrill seeking - Motivation: "')[4]) 
    print(calcPearSpear(sensation_seeking, medium_emotion_motivation, 'Sensation seeking - Motivation: "')[4]) 

def statEmotionBigFive(emotions, bigfives, ids):
    
    medium_emotion_positiv = []
    medium_emotion_motivation = []
    
    agreeableness = []
    conscientiousness = []
    extraversion = []
    neuroticism = []
    openess = []
    
    for l in ids:  
        avg_em = LapUtility.getAvgEmotions(emotions[l])
        medium_emotion_positiv.append(avg_em[0])
        medium_emotion_motivation.append(avg_em[1])
        
        bigfive = bigfives[l]
        agreeableness.append(bigfive.getAgreeableness())
        conscientiousness.append(bigfive.getConscientiousness())
        extraversion.append(bigfive.getExtraversion())
        neuroticism.append(bigfive.getNeuroticism())
        openess.append(bigfive.getOpenness())
        
    print(calcPearSpear(medium_emotion_positiv, agreeableness, 'Agreeableness - Positiv: "')[4]) 
    print(calcPearSpear(medium_emotion_positiv, conscientiousness, 'Conscientiousness - Positiv: "')[4])   
    print(calcPearSpear(medium_emotion_positiv, extraversion, 'Extraversion - Positiv: "')[4])   
    print(calcPearSpear(medium_emotion_positiv, neuroticism, 'Neuroticism - Positiv: "')[4])   
    print(calcPearSpear(medium_emotion_positiv, openess, 'Openess - Positiv: "')[4])    
    
    print(calcPearSpear(medium_emotion_motivation, agreeableness, 'Agreeableness - Motivation: "')[4]) 
    print(calcPearSpear(medium_emotion_motivation, conscientiousness, 'Conscientiousness - Motivation: "')[4])   
    print(calcPearSpear(medium_emotion_motivation, extraversion, 'Extraversion - Motivation: "')[4])   
    print(calcPearSpear(medium_emotion_motivation, neuroticism, 'Neuroticism - Motivation: "')[4])   
    print(calcPearSpear(medium_emotion_motivation, openess, 'Openess - Motivation: "')[4])    
    
def statGhostPeformance(laps, ids):
    errors = []
    win = []
    dif = []
    abs_dif = []
    
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1:
                continue
            else:
                win.append(res[0])
                dif.append(res[1])
                abs_dif.append(abs(res[1]))
                errors.append(lap.getNrErrors())
                
    print(calcPearSpear(win, errors, 'Win - Errors: "')[4]) 
    print(calcPearSpear(dif, errors, 'Time Dif Opponent - Errors: "')[4])  
    print(calcPearSpear(abs_dif, errors, 'Abs Time Dif Opponent - Errors: "')[4])  
    
def statGhostDiffErrors(laps, ids):
    error_time_dif = []
    ghost_dist = []
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1:
                continue
            else:
                time_diff, pos_diff = LapUtility.getErrorTimeDifToGhost(laps, lap)
                error_time_dif = error_time_dif + time_diff
                ghost_dist = ghost_dist + pos_diff
                
    print(calcPearSpear(ghost_dist, error_time_dif, 'Dist Diff - Time Diff: "')[4])  
    
def statGhostPeformanceEmotions(laps, emotions, ids):
    errors = []
    win = []
    dif = []
    dif_abs = []
    
    emotion_positiv_high = []
    emotion_positiv_middle = []
    emotion_motivation_high = []
    emotion_motivation_middle = []
    
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1:
                continue
            else:
                win.append(res[0])
                dif.append(res[1])
                dif_abs.append(abs(res[1]))
                errors.append(lap.getNrErrors())
                emotion_positiv_high.append(emotions[lap.id][lap.round-1].getHighCoord()[0])
                emotion_positiv_middle.append(emotions[lap.id][lap.round-1].getMiddleCoord()[0])
                emotion_motivation_high.append(emotions[lap.id][lap.round-1].getHighCoord()[1])
                emotion_motivation_middle.append(emotions[lap.id][lap.round-1].getMiddleCoord()[1])
                
    print(calcPearSpear(emotion_positiv_high, errors, 'Positiv High - Errors: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, errors, 'Positiv Middle - Errors: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, errors, 'Motivation High - Errors: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, errors, 'Motivation Middle - Errors: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, win, 'Positiv High - Win: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, win, 'Positiv Middle - Win: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, win, 'Motivation High - Win: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, win, 'Motivation Middle - Win: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, dif, 'Positiv High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, dif, 'Positiv Middle - Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, dif, 'Motivation High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, dif, 'Motivation Middle - Win Time Difference: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, dif_abs, 'Positiv High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, dif_abs, 'Positiv Middle - Abs Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, dif_abs, 'Motivation High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, dif_abs, 'Motivation Middle - Abs Win Time Difference: "')[4]) 
    
    # Z-score 
    emotion_positiv_high_z = stats.zscore(emotion_positiv_high)
    emotion_positiv_middle_z = stats.zscore(emotion_positiv_middle)
    emotion_motivation_high_z = stats.zscore(emotion_motivation_high)
    emotion_motivation_middle_z = stats.zscore(emotion_motivation_middle)
    
    print("Z-Score")
    
    print(calcPearSpear(emotion_positiv_high_z, errors, 'Positiv High - Errors: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle_z, errors, 'Positiv Middle - Errors: "')[4]) 

    print(calcPearSpear(emotion_motivation_high_z, errors, 'Motivation High - Errors: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle_z, errors, 'Motivation Middle - Errors: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high_z, win, 'Positiv High - Win: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle_z, win, 'Positiv Middle - Win: "')[4]) 

    print(calcPearSpear(emotion_motivation_high_z, win, 'Motivation High - Win: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle_z, win, 'Motivation Middle - Win: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high_z, dif, 'Positiv High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle_z, dif, 'Positiv Middle - Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high_z, dif, 'Motivation High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle_z, dif, 'Motivation Middle - Win Time Difference: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high_z, dif_abs, 'Positiv High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle_z, dif_abs, 'Positiv Middle - Abs Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high_z, dif_abs, 'Motivation High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle_z, dif_abs, 'Motivation Middle - Abs Win Time Difference: "')[4]) 
    
def statLastRoundEmotionsPeformance(laps, emotions, ids):
    errors = []
    win = []
    dif = []
    dif_abs = []
    lap_time = []
    
    emotion_positiv_high = []
    emotion_positiv_middle = []
    emotion_motivation_high = []
    emotion_motivation_middle = []
    
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1:
                continue
            else:
                win.append(res[0])
                dif.append(res[1])
                dif_abs.append(abs(res[1]))
                errors.append(lap.getNrErrors())
                emotion_positiv_high.append(emotions[lap.id][lap.round-2].getHighCoord()[0])
                emotion_positiv_middle.append(emotions[lap.id][lap.round-2].getMiddleCoord()[0])
                emotion_motivation_high.append(emotions[lap.id][lap.round-2].getHighCoord()[1])
                emotion_motivation_middle.append(emotions[lap.id][lap.round-2].getMiddleCoord()[1])
                lap_time.append(lap.getLapTime())
                
                
    print(calcPearSpear(emotion_positiv_high, errors, 'Last Round Positiv High - Errors: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, errors, 'Last Round Positiv Middle - Errors: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, errors, 'Last Round Motivation High - Errors: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, errors, 'Last Round Motivation Middle - Errors: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, win, 'Last Round Positiv High - Win: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, win, 'Last Round Positiv Middle - Win: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, win, 'Last Round Motivation High - Win: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, win, 'Last Round Motivation Middle - Win: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, dif, 'Last Round Positiv High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, dif, 'Last Round Positiv Middle - Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, dif, 'Last Round Motivation High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, dif, 'Last Round Motivation Middle - Win Time Difference: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, dif_abs, 'Last Round Positiv High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, dif_abs, 'Last Round Positiv Middle - Abs Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, dif_abs, 'Last Round Motivation High - Abs Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, dif_abs, 'Last Round Motivation Middle - Abs Win Time Difference: "')[4]) 
    
    print()
    
    print(calcPearSpear(emotion_positiv_high, lap_time, 'Last Round Positiv High - Lap time: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, lap_time, 'Last Round Positiv Middle - Lap time: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, lap_time, 'Last Round Motivation High - Lap time: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, lap_time, 'Last Round Motivation Middle - Lap time: "')[4]) 
  
def statEmotionsWhenWinning(laps, emotions, ids):
    win = []
    dif = []
    
    emotion_positiv_high = []
    emotion_positiv_middle = []
    emotion_motivation_high = []
    emotion_motivation_middle = []
    
    for i in ids:
        if(len(laps[i]) < 6):
            continue
        
        for lap in laps[i]:
            res = lap.getWinOrLoss()
            if res[0] == -1 or res[0] == 1:
                continue
            else:
                win.append(res[0])
                dif.append(abs(res[1]))
                emotion_positiv_high.append(emotions[lap.id][lap.round-1].getHighCoord()[0])
                emotion_positiv_middle.append(emotions[lap.id][lap.round-1].getMiddleCoord()[0])
                emotion_motivation_high.append(emotions[lap.id][lap.round-1].getHighCoord()[1])
                emotion_motivation_middle.append(emotions[lap.id][lap.round-1].getMiddleCoord()[1])
                
    
    print(calcPearSpear(emotion_positiv_high, dif, 'Positiv High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_positiv_middle, dif, 'Positiv Middle - Win Time Difference: "')[4]) 

    print(calcPearSpear(emotion_motivation_high, dif, 'Motivation High - Win Time Difference: "')[4]) 
    print(calcPearSpear(emotion_motivation_middle, dif, 'Motivation Middle - Win Time Difference: "')[4]) 
    