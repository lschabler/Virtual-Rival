'''
Created on 02.02.2019

@author: Lukas
'''

import gspread
from oauth2client.service_account import ServiceAccountCredentials

class Bigfive:
    def __init__(self, idpart, agreeablenesspart, conscientiousnesspart, extraversionpart, neuroticismpart, openesspart):
        self.id = idpart
        self.agreeableness = agreeablenesspart
        self.conscientiousness = conscientiousnesspart
        self.extraversion = extraversionpart
        self.neuroticism = neuroticismpart
        self.openess = openesspart
        
    def toString(self):
        return str(self.id) + " " + str(self.agreeableness)+ " " + str(self.conscientiousness)+ " " + str(self.extraversion)+ " " + str(self.neuroticism)+ " " + str(self.openess)
    
    def getAgreeableness(self):
        return self.agreeableness
    
    def getConscientiousness(self):
        return self.conscientiousness
    
    def getExtraversion(self):
        return self.extraversion
    
    def getNeuroticism(self):
        return self.neuroticism
    
    def getOpenness(self):
        return self.openess
    
class Bigfivereader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('vbigfive (Data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        bigfive_list = {}
        for r in self.recs:
            rid = r['ID']
            agreeableness = r['Agreeableness']
            conscientiousness = r['Conscientiousness']
            extraversion = r['Extraversion']
            neuroticism = r['Neuroticism']
            openness = r['Openness']
            
            bigfive_list[rid] = Bigfive(rid, agreeableness, conscientiousness, extraversion, neuroticism, openness)
            
        return bigfive_list