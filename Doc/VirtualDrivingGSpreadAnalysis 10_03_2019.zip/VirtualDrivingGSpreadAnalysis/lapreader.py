import gspread
from oauth2client.service_account import ServiceAccountCredentials

def isfloat(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

class Vector3:
    def __init__(self, xp, yp, zp):
        self.x = xp
        self.y = yp
        self.z = zp
    
    def toString(self):
        return str(self.x) + ' ' + str(self.y) + ' ' + str(self.z)

class Run:

    def __init__(self, idpart, roundpart, speedpart, timepart, xpart, ypart, zpart, oppidpart, opproundpart, mmrpart, typepart, avgfpspart, maxfpspart, 
                 resetpointstime, resetpointsposition, resetpointscheckpoint, contactpointstime, contactpointsposition):
        self.id = idpart
        self.round = roundpart
        self.speed = speedpart
        self.time = timepart
        self.pos_x = xpart
        self.pos_y = ypart
        self.pos_z = zpart
        self.oppid = oppidpart
        self.oppround = opproundpart
        self.mmr = mmrpart
        self.type = typepart
        self.avgfps = avgfpspart
        self.maxfps = maxfpspart
        self.resetpoints_time = resetpointstime
        self.resetpoints_position = resetpointsposition
        self.resetpoints_checkpoint = resetpointscheckpoint
        self.contactpoints_time = contactpointstime
        self.contactpoints_position = contactpointsposition
        self.win_or_loss = -1
        self.win_or_loss_time_dif = 0
    
    def getResetpointsPositionAsList(self):
        x = []
        y = []
        z = []
        for r in self.resetpoints_position:
            x.append(r.x)
            y.append(r.y)
            z.append(r.z)
        return x,y,z
    
    def getContactpointsPositionAsList(self):
        x = []
        y = []
        z = []
        for r in self.contactpoints_position:
            x.append(r.x)
            y.append(r.y)
            z.append(r.z)
        return x,y,z
    
    def toString(self):
        return str(self.id) + " " + str(self.round)
    
    def getAvgFPS(self):
        return self.avgfps
    
    def getLapTime(self):
        return self.time[-1]
    
    def setWinOrLoss(self, res, time_dif):
        self.win_or_loss = res
        self.win_or_loss_time_dif = time_dif
        
    def getWinOrLoss(self):
        return [self.win_or_loss, self.win_or_loss_time_dif]
    
    def getNrErrors(self):
        nr_errors = 0
        last_contact_point = 0
        for i in range(0,len(self.contactpoints_time)):
            
            if(abs(self.contactpoints_time[i] - last_contact_point) > 0.5):
                last_contact_point = self.contactpoints_time[i]
                nr_errors+=1 
        return nr_errors

class Lapreader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('Round1 (data)').sheet1
        self.recs = self.wks.get_all_records()

    def parse(self):
            
        runs = {}
        for r in self.recs:
            current_time = []
            current_speed = []
            current_position_x = []
            current_position_y = []
            current_position_z = []
            
            id_string = r['ID']
            round_string = r['Round']
            speed_string = r['Speed']
            time_string = r['Time']
            position_string = r['Position']
            oppid_string = r['OppID']
            oppround_string = r['OppRound']
            mmr_string = r['MMR']
            type_string = r['Type']
            avgfps_string = r['AvgFps']
            maxfps_string = r['MaxFps']
            resetpoints_string = r['Resetpoints']
            contactpoints_string = r['Contactpoints']
            
            if speed_string == '':
                continue;
            
            for s in speed_string.split(' '):
                if(s==''):
                    break;
                current_speed.append(float(s))
            
            for t in time_string.split(' '):
                if(t==''):
                    break;
                current_time.append(float(t))
                
            position_splitted = position_string.split(' ');
            for i in range(0,len(position_splitted),3):
                if(position_splitted[i] == ''):
                    break;
                current_position_x.append(float(position_splitted[i]))
                current_position_y.append(float(position_splitted[i+1]))
                current_position_z.append(float(position_splitted[i+2]))
                
            current_resetpoints_time = []
            current_resetpoints_position = []
            current_resetpoints_checkpoints = []
            resetpoints_splitted = resetpoints_string.split(' ');
            for i in range(0,len(resetpoints_splitted),7):
                if(resetpoints_splitted[i] == ''):
                    break
                if(isfloat(resetpoints_splitted[i]) == False):
                    break
                current_resetpoints_time.append(float(resetpoints_splitted[i]))
                current_resetpoints_position.append(Vector3(float(resetpoints_splitted[i+1]), float(resetpoints_splitted[i+2]), float(resetpoints_splitted[i+3])))
                current_resetpoints_checkpoints.append(Vector3(float(resetpoints_splitted[i+4]), float(resetpoints_splitted[i+5]), float(resetpoints_splitted[i+6]))) 
                
            current_contactpoints_time = []
            current_contactpoints_position = []
            contactpoints_splitted = contactpoints_string.split(' ');
            for i in range(0,len(contactpoints_splitted),4):
                if(contactpoints_splitted[i] == ''):
                    break
                current_contactpoints_time.append(float(contactpoints_splitted[i]))
                current_contactpoints_position.append(Vector3(float(contactpoints_splitted[i+1]), float(contactpoints_splitted[i+2]), float(contactpoints_splitted[i+3])))
                
            rn = Run(id_string,round_string, current_speed, current_time, current_position_x, current_position_y, current_position_z, 
                     oppid_string, oppround_string, mmr_string, type_string, avgfps_string, maxfps_string, 
                     current_resetpoints_time, current_resetpoints_position, current_resetpoints_checkpoints, current_contactpoints_time, current_contactpoints_position)
            if rn.id not in runs.keys():
                runs[rn.id] = []
            runs[rn.id].append(rn)
        return runs
        