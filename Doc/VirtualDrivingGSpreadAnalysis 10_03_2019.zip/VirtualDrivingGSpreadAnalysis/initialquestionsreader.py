'''
Created on 06.02.2019

@author: Lukas
'''

import gspread
from oauth2client.service_account import ServiceAccountCredentials

class InitialQuestions:
    def __init__(self, idpart, typepart, drivingpart, videogamepart):
        self.id = idpart
        self.type = typepart
        self.driving = drivingpart
        self.videogame = videogamepart
        
    def toString(self):
        return str(self.id) + " " + str(self.type)
    
    def getType(self):
        return self.type
    
    def isTime(self):
        if self.type == "TIME":
            return True
        else:
            return False

class Initialquestionsreader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('vinitialquestions (Data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        question_list = {}
        for r in self.recs:
            rid = r['ID']
            qtype = r['Type']
            qdriving = r['Driving']
            qvideogame = r['Videogame']

            question_list[rid] = InitialQuestions(rid, qtype, qdriving, qvideogame)
            
        return question_list