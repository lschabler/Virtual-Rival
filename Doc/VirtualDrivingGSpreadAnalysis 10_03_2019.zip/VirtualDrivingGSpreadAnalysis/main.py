import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy import stats

from betweenquestionsreader import Betweenquestionreader
from agereader import Agereader
from initialquestionsreader import Initialquestionsreader
from lapreader import Lapreader
from sensationreader import Sensationreader
from bigfivereader import Bigfivereader
from wheelofemotionsreader import Emotionreader
import vdstatistics
import LapUtility
import vdgraphs

# Personality factors are associated with simulated driving outcomes across the driving lifespan
# https://towardsdatascience.com/inferential-statistics-series-t-test-using-numpy-2718f8f9bf2f

    

first_round1_ids = ['66-07-B9-A7-68-EE-F9-D0-41-CC-B6-3E-33-77-E8-8E-AA-CC-B7-A2-C5-2C-52-77-B8-CE-D6-7B-1A-11-FB-25',
              'F3-B8-AE-37-1D-47-26-59-07-72-EA-5D-DE-3F-EA-B7-C0-1A-55-9A-52-9B-4F-BD-89-1C-B3-23-72-35-36-20',
              'BE-68-F8-80-54-5D-E2-92-A0-F7-4E-8C-D2-35-AC-89-18-73-24-0B-79-86-4F-B5-A0-BE-F4-32-8D-6B-60-C1',
              '08-39-C7-58-C3-45-CA-4C-89-50-2A-CA-AC-E6-BA-CD-26-55-43-2F-3F-9F-EA-E3-67-73-81-49-14-4A-30-A2',
              '3C-03-15-D5-70-84-73-E0-6B-6C-3D-D1-79-FD-51-6B-8A-49-D1-B3-4F-59-8A-B1-58-A6-08-15-09-EE-41-DA',
              '60-93-01-BB-B6-B6-76-83-A0-49-3D-5A-FD-DA-D2-CD-BD-D0-C4-EA-6C-72-44-00-49-77-C6-C6-0A-B5-08-DD',
              '74-FE-1C-C9-A3-2C-EF-A2-2F-DB-7E-7C-A1-76-41-02-35-98-ED-83-1F-39-57-DD-CA-EA-E8-9C-38-B6-7B-D4',
              '91-5E-2F-9F-0C-6F-08-1F-BC-AD-04-96-26-07-6D-48-20-44-83-A2-00-D2-D5-DC-13-4D-A4-C8-30-1B-0E-A1',
              'FF-7F-F4-18-70-63-62-A9-32-82-45-F9-BD-06-70-2B-35-BF-A5-C4-F0-2B-48-F5-1C-DC-F0-02-E9-B6-0C-E4']



sensations = Sensationreader().parse()

bigfive = Bigfivereader().parse()

emotions = Emotionreader().parse()

initialquestions = Initialquestionsreader().parse()



laps = Lapreader().parse()

ages = Agereader().parse()

betweenquestions = Betweenquestionreader().parse()

round1_ids = LapUtility.filterIDs(first_round1_ids, laps)
LapUtility.getWinOrLoss(round1_ids, laps)

[time_ids, ghost_ids] = LapUtility.filterType(round1_ids, initialquestions)



#vdgraphs.graphAgeHistogram(ages, round1_ids)

#vdstatistics.statSensationRound(laps, sensations, round1_ids)

#vdstatistics.statBigFiveRound(laps, bigfive, round1_ids)

#vdgraphs.graphLapHistogram(laps, round1_ids)

#vdstatistics.statFunSkill(laps, betweenquestions, round1_ids)

#vdstatistics.statFunSkillDrivingPeformance(laps, betweenquestions, round1_ids)

#vdstatistics.statFunSkillSensation(betweenquestions, sensations, round1_ids)

#vdstatistics.statGhostPeformance(laps, round1_ids)

#vdstatistics.statGhostDiffErrors(laps, round1_ids)

#vdstatistics.statEmotionSensation(emotions, sensations, round1_ids)

#vdstatistics.statEmotionsDrivingPeformance(laps, emotions, round1_ids)

#vdstatistics.statEmotionBigFive(emotions, bigfive, round1_ids)

#vdstatistics.statGhostPeformanceEmotions(laps, emotions, round1_ids)

#vdstatistics.statLastRoundEmotionsPeformance(laps, emotions, round1_ids)

print('time')
#vdstatistics.statEmotionsWhenWinning(laps, emotions, time_ids)
vdstatistics.statGhostPeformanceEmotions(laps, emotions, time_ids)

print('ghost')
#vdstatistics.statEmotionsWhenWinning(laps, emotions, ghost_ids)
vdstatistics.statGhostPeformanceEmotions(laps, emotions, ghost_ids)


for l in round1_ids:    
    if(len(laps[l]) < 6):
        continue
    
    if not (l in round1_ids):
        continue
    
    #for r in emotions[l]:
    #    print(r.getHighCoord())
    
    '''
    for r in laps[l]:
        print(r.toString())
        
        #if(r.resetpoints_position == []):
        #    continue
                
        plt.plot(r.pos_x, r.pos_z)
        
        rx, ry, rz = r.getResetpointsPositionAsList()
        plt.plot(rx, rz, 'go')
        
        cx, cy, cz = r.getContactpointsPositionAsList()
        plt.plot(cx, cz, 'ro')

        plt.show()
    '''    
