'''
Created on 01.02.2019

@author: Lukas
'''

import gspread
from oauth2client.service_account import ServiceAccountCredentials

class Sensation:
    def __init__(self, idpart, experiencepart, disinhibitionpart, boredompart, thrillpart):
        self.id = idpart
        self.experience = experiencepart
        self.disinhibition = disinhibitionpart
        self.bordom = boredompart
        self.thrill = thrillpart
        self.sensation = experiencepart + disinhibitionpart + boredompart + thrillpart
        
    def toString(self):
        return str(self.id) + " " + str(self.sensation)
    
    def getSensationSeeking(self):
        return self.sensation
    
    def getExperienceSeeking(self):
        return self.experience
    
    def getDisinhibitionSeeking(self):
        return self.disinhibition
    
    def getBordomSeeking(self):
        return self.bordom
    
    def getThrillSeeking(self):
        return self.thrill

class Sensationreader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('sensationseekingquestionary (Data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        sensations_list = {}
        for r in self.recs:
            id_string = r['ID']
            experience_seeking = r['Experienceseeking']
            disinhibition_seeking = r['Disinhibition']
            boredom_susceptibility = r['Boredomsusceptibility']
            thrill_adventure_seeking = r['Thrillandadventureseeking']
            
            sensations_list[id_string] = Sensation(id_string, experience_seeking, disinhibition_seeking, boredom_susceptibility, thrill_adventure_seeking)
        return sensations_list