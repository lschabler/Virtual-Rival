'''
Created on 06.02.2019

@author: Lukas
'''

import gspread
from oauth2client.service_account import ServiceAccountCredentials

class Agereader:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.credentials = ServiceAccountCredentials.from_json_keyfile_name('VirtualDriving-c52ef56a9a29.json', self.scope)
        self.gc = gspread.authorize(self.credentials)
        self.wks = self.gc.open('Age (Data)').sheet1
        self.recs = self.wks.get_all_records()
        
    def parse(self):        
        age_list = {}
        for r in self.recs:
            rid = r['ID']
            age = r['Age']

            age_list[rid] = age
            
        return age_list