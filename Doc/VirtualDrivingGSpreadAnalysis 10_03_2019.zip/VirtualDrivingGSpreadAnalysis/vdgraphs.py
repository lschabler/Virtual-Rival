'''
Created on 02.02.2019

@author: Lukas
'''

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats


def graphLapHistogram(laps, ids):
    
    track_times = []
    eval_times = []
    
    for l in ids:
        if(len(laps[l]) < 6):
            continue
        
        for lap in laps[l]:
            if(lap.type == 'TRACK1'):
                track_times.append(lap.time[-1])
            else:
                eval_times.append(lap.time[-1])
    
    sns.distplot(eval_times, kde=False, rug=True, fit=stats.gamma);
    plt.show()
    
    sns.distplot(track_times, kde=False, rug=True, fit=stats.gamma);
    plt.show()
    
def graphAgeHistogram(ages, ids):
    
    age = []
    for i in ids:
        age.append(ages[i])
                
    sns.distplot(age, kde=False, rug=True, fit=stats.gamma);
    plt.show()